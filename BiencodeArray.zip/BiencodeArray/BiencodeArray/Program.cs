﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace BiencodeArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = ReadArrayFromFile();

            MergeSort(arr);

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i] + " ");
            }
            
            Console.ReadLine();
        }
        static public int[] ReadArrayFromFile()
        {
            using (StreamReader sr = new StreamReader("array.txt"))
            {

                string arr = sr.ReadLine();
                int[] a = arr.Split(',').
                Where(x => !string.IsNullOrWhiteSpace(x)).
                Select(x => int.Parse(x)).ToArray();
               
                return a;
            }
        }
        static public void MergeSort(int[] items)
        {
            if(items.Length <= 1)
            {
                return;
            }

            int leftSize = items.Length / 2;
            int rightSize = items.Length - leftSize;

            int[] left = new int[leftSize];
            int[] right = new int[rightSize];

            for(int i=0; i < leftSize; i++)
            {
                left[i] = items[i];
            }

            int k = leftSize;
            for (int i = 0; i < rightSize; i++)
            {
                right[i] = items[k];
                k++;
            }

            MergeSort(left);
            MergeSort(right);

            Merge(items, left, right);
        }
        static private void Merge(int[] items, int[] left, int[] right)
        {
            int leftIndex = 0;
            int rightIndex = 0;
            int targetIndex = 0;
            int remaining = left.Length + right.Length;

            while(remaining > 0)
            {
                if(leftIndex >= left.Length)
                {
                    items[targetIndex] = right[rightIndex++];
                }

                else if(rightIndex >= right.Length)
                {
                    items[targetIndex] = left[leftIndex++];
                }

                else if(left[leftIndex].CompareTo(right[rightIndex]) < 0)
                {
                    items[targetIndex] = right[rightIndex++];
                }

                else
                {
                    items[targetIndex] = left[leftIndex++];
                }

                targetIndex++;
                remaining--;
            }
        }
    }
}
