﻿using BiencodeCarOwners.DataAccess;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BiencodeCarOwners.BusinessLogic.Configs
{
    public static class DbContextConfig
    {
        public static void ConfigureDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("DbConnection");

            services.AddDbContext<CarAndOwnerContext>(options => options.UseSqlServer(connectionString));
        }
    }
}
