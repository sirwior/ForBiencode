﻿using BiencodeCarOwners.BusinessLogic.Services.Interfaces;
using BiencodeCarOwners.DataAccess.Repositories;
using BiencodeCarOwners.DataAccess.Repositories.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace BiencodeCarOwners.BusinessLogic.Configs
{
    public static class DependencyInjectionConfig
    {
        public static void ConfigureDependencyInjection(this IServiceCollection services)
        {
            services.AddScoped<ICarService, CarService>();
            services.AddScoped<IOwnerService, OwnerService>();

            services.AddScoped<ICarRepository, CarRepository>();
            services.AddScoped<IOwnerRepository, OwnerRepository>();
            services.AddScoped<ICarOwnerRepository, CarOwnerRepository>();
        }
    }
}
