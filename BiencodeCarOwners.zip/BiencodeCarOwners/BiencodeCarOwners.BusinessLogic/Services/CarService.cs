﻿using System.Collections.Generic;
using BiencodeCarOwners.BusinessLogic.Services.Interfaces;
using BiencodeCarOwners.DataAccess.Repositories.Interfaces;
using BiencodeCarOwners.Models;
using System.Linq;
using BiencodeCarOwners.Models.Enums;

namespace BiencodeCarOwners.BusinessLogic
{
    public class CarService : ICarService
    {
        private readonly ICarRepository _carRepository;
        private readonly IOwnerRepository _ownerRepository;

        public CarService(ICarRepository carRepository, IOwnerRepository ownerRepository)
        {
            _carRepository = carRepository;
            _ownerRepository = ownerRepository;
        }

        public List<Car> GetAllCars()
        {
            var cars = _carRepository.GetAll();

            return cars.Select(c => new Car()
            {
                Id = c.Id,
                Brand = c.Brand,
                CarType = (CarType)c.CarType,
                Model = c.Model,
                Price = c.Price,
                YearOfMade = c.YearOfMade
            })
            .ToList();
        }

        public CarProfile GetCarProfile(int carId)
        {
            CarProfile result = new CarProfile();
            var car = _carRepository.GetById(carId);
            result.Car = new Car()
            {
                Id = car.Id,
                Brand = car.Brand,
                CarType = (CarType)car.CarType,
                Model = car.Model,
                Price = car.Price,
                YearOfMade = car.YearOfMade
            };
            var owners = _ownerRepository.GetOwnersByCarId(carId);

            result.Owners = owners.Select(o => new Owner()
            {
                Id = o.Id,
                Name = o.Name,
                Surname = o.Surname,
                YearOfBirth = o.YearOfBirth,
                DriveExp = o.DriveExp
            })
            .ToList();
            return result;
        }
    }
}
