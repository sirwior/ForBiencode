﻿using BiencodeCarOwners.BusinessLogic.Services.Interfaces;
using BiencodeCarOwners.DataAccess.Repositories.Interfaces;
using BiencodeCarOwners.Models;
using BiencodeCarOwners.Models.Enums;
using System.Collections.Generic;
using System.Linq;

namespace BiencodeCarOwners.BusinessLogic
{
    class OwnerService : IOwnerService
    {
        private readonly ICarRepository _carRepository;
        private readonly IOwnerRepository _ownerRepository;

        public OwnerService(ICarRepository carRepository, IOwnerRepository ownerRepository)
        {
            _carRepository = carRepository;
            _ownerRepository = ownerRepository;
        }

        public List<Owner> GetAllOwners()
        {
            var owners = _ownerRepository.GetAll();

            return owners.Select(o => new Owner()
            {
                Id = o.Id,
                Name = o.Name,
                Surname = o.Surname,
                YearOfBirth = o.YearOfBirth,
                DriveExp = o.DriveExp
            })
            .ToList();
        }

        public OwnerProfile GetOwnerProfile(int ownerId)
        {
            OwnerProfile result = new OwnerProfile();
            var owner = _ownerRepository.GetById(ownerId);
            result.Owner = new Owner()
            {
                Id = owner.Id,
                Name = owner.Name,
                Surname = owner.Surname,
                YearOfBirth = owner.YearOfBirth,
                DriveExp = owner.DriveExp
            };
            var cars = _carRepository.GetCarByOwnerId(ownerId);

            result.Cars = cars.Select(c => new Car()
            {
                Id = c.Id,
                Brand = c.Brand,
                CarType = (CarType)c.CarType,
                Model = c.Model,
                Price = c.Price,
                YearOfMade = c.YearOfMade
            })
            .ToList();
            return result;
        }
    }
}
