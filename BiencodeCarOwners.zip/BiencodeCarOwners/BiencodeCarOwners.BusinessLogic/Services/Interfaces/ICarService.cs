﻿using BiencodeCarOwners.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BiencodeCarOwners.BusinessLogic.Services.Interfaces
{
    public interface ICarService
    {
        List<Car> GetAllCars();
        CarProfile GetCarProfile(int carId);
    }
}
