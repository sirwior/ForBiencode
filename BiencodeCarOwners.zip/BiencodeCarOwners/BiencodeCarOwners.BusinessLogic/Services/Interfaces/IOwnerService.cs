﻿using BiencodeCarOwners.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BiencodeCarOwners.BusinessLogic.Services.Interfaces
{
    public interface IOwnerService
    {

        List<Owner> GetAllOwners();
        OwnerProfile GetOwnerProfile(int ownerId);
    }
}
