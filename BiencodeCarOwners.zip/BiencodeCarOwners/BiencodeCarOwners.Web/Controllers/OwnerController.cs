﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BiencodeCarOwners.BusinessLogic.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BiencodeCarOwners.Web.Controllers
{
    public class OwnerController : Controller
    {
        private readonly IOwnerService _ownerService;

        public OwnerController(IOwnerService ownerService)
        {

        }
    }
}