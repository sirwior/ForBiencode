﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BiencodeCarOwners.BusinessLogic.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BiencodeCarOwners.Web.Controllers
{
    public class CarController : Controller
    {
        private readonly ICarService _carService;
        
        public CarController(ICarService carService)
        {
            _carService = carService;
        }

        [Route("Car/List")]
        public IActionResult CarList()
        {
            var result = _carService.GetAllCars();

            return View(result);
        }

        [Route("Car/Profile/{carId}")]
        public IActionResult CarProfile(int carId)
        {
            var result = _carService.GetCarProfile(carId);

            return View(result);
        }
    }
}