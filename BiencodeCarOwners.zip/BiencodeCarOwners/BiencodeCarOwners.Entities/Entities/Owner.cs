﻿using BiencodeCarOwners.DataAccess.Entities.Interfaces;

namespace BiencodeCarOwners.DataAccess.Entities
{
    public class Owner : IBaseEntity
    {
        public int Id { get; set; }

        public string Name { get; set; }
        public string Surname { get; set; }
        public int YearOfBirth { get; set; }
        public int DriveExp { get; set; }
    }
}
