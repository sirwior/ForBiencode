﻿using BiencodeCarOwners.DataAccess.Entities.Interfaces;
using BiencodeCarOwners.Entities.Enums;

namespace BiencodeCarOwners.DataAccess.Entities
{
    public class Car : IBaseEntity
    {
        public int Id { get; set; }
        public string Model { get; set; }
        public string Brand { get; set; }
        public CarType CarType { get; set; }
        public int Price { get; set; }
        public int YearOfMade { get; set; }
    }
}