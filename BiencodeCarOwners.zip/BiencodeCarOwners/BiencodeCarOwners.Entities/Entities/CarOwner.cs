﻿using BiencodeCarOwners.DataAccess.Entities.Interfaces;

namespace BiencodeCarOwners.DataAccess.Entities
{
    public class CarOwner : IBaseEntity
    {
        public int Id { get; set; }

        public int CarId { get; set; }
        public int OwnerId { get; set; }

        public virtual Car Car { get; set; }
        public virtual Owner Owner { get; set; }
    }
}
