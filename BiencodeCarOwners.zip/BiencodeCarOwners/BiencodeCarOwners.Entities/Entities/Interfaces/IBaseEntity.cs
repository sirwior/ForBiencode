﻿namespace BiencodeCarOwners.DataAccess.Entities.Interfaces
{
    public interface IBaseEntity
    {
        int Id { get; set; }
    }
}
