﻿namespace BiencodeCarOwners.Entities.Enums
{
    public enum CarType
    {
        Passenger = 0,
        Track = 1
    }
}
