﻿using BiencodeCarOwners.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace BiencodeCarOwners.DataAccess
{
    public class CarAndOwnerContext : DbContext
    {
        public DbSet<Car> Cars { get; set; }
        public DbSet<Owner> Owners { get; set; }
        public DbSet<CarOwner> CarOwner { get; set; }

        public CarAndOwnerContext(DbContextOptions<CarAndOwnerContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }
    }
}