﻿using BiencodeCarOwners.DataAccess.Entities;
using System.Collections.Generic;

namespace BiencodeCarOwners.DataAccess.Repositories.Interfaces
{
    public interface IOwnerRepository : IBaseRepository<Owner>
    {
        List<Owner> GetOwnersByCarId(int carId);

    }
}
