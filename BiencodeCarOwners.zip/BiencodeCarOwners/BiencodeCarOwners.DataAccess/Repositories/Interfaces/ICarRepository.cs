﻿
using BiencodeCarOwners.DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BiencodeCarOwners.DataAccess.Repositories.Interfaces
{
    public interface ICarRepository : IBaseRepository<Car>
    {
        List<Car> GetCarByOwnerId(int ownerId);

    }
}
