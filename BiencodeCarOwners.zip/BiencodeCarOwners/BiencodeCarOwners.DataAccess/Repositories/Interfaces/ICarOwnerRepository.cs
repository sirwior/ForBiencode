﻿using BiencodeCarOwners.DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BiencodeCarOwners.DataAccess.Repositories.Interfaces
{
    public interface ICarOwnerRepository : IBaseRepository<CarOwner>
    {
        List<CarOwner> GetByCarId(int carId);
        List<CarOwner> GetByOwnerId(int ownerId);

    }
}
