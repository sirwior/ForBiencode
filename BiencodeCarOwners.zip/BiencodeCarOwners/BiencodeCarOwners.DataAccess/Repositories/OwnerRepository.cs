﻿using BiencodeCarOwners.DataAccess.Entities;
using BiencodeCarOwners.DataAccess.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiencodeCarOwners.DataAccess.Repositories
{
    public class OwnerRepository : BaseRepository<Owner>, IOwnerRepository
    {
        public OwnerRepository(CarAndOwnerContext context) : base(context)
        {

        }

        public List<Owner> GetOwnersByCarId(int carId)
        {
            return _context.CarOwner
                .Where(co => co.CarId == carId)
                .Join(_context.Owners, carOwner => carOwner.OwnerId, owner => owner.Id, (co, o) => o)
                .ToList();

        }
    }
}
