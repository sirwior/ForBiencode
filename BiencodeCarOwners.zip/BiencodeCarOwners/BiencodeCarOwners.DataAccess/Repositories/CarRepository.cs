﻿using BiencodeCarOwners.DataAccess.Entities;
using BiencodeCarOwners.DataAccess.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiencodeCarOwners.DataAccess.Repositories
{
    public class CarRepository : BaseRepository<Car>, ICarRepository
    {
        public CarRepository(CarAndOwnerContext context) : base(context)
        {
        }

        public List<Car> GetCarByOwnerId(int ownerId)
        {
            return _context.CarOwner
                .Where(co => co.OwnerId == ownerId)
                .Join(_context.Cars, carOwner => carOwner.CarId, car => car.Id, (carOwner, car) => car)
                .ToList();
        }
    }
}
