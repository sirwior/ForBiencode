﻿using BiencodeCarOwners.DataAccess.Entities.Interfaces;
using BiencodeCarOwners.DataAccess.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiencodeCarOwners.DataAccess.Repositories
{
    public class BaseRepository<T> : IBaseRepository<T>
        where T : class, IBaseEntity
    {

        protected readonly CarAndOwnerContext _context;

        public BaseRepository(CarAndOwnerContext context)
        {
            _context = context;
        }
        public void Create(T item)
        {
            _context.Set<T>().Add(item);
        }

        public void Delete(T item)
        {
            _context.Set<T>().Remove(item);

        }

        public IEnumerable<T> GetAll()
        {
            return _context.Set<T>().ToList();
        }

        public T GetById(int id)
        {
            return _context.Set<T>().Where(x => x.Id == id).SingleOrDefault();
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public void Update(T item)
        {
            _context.Set<T>().Update(item);
        }
    }
}
