﻿using BiencodeCarOwners.DataAccess.Entities;
using BiencodeCarOwners.DataAccess.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiencodeCarOwners.DataAccess.Repositories
{
    public class CarOwnerRepository : BaseRepository<CarOwner>, ICarOwnerRepository
    {
        public CarOwnerRepository(CarAndOwnerContext context) : base(context)
        {
        }

        public List<CarOwner> GetByCarId(int carId)
        {
            return _context.CarOwner
                .Where(co => co.CarId == carId)
                .ToList();
        }

        public List<CarOwner> GetByOwnerId(int ownerId)
        {
            return _context.CarOwner
                 .Where(co => co.OwnerId == ownerId)
                 .ToList();
        }
    }
}
