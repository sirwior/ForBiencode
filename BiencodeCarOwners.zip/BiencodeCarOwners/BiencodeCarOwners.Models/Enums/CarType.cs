﻿namespace BiencodeCarOwners.Models.Enums
{
    public enum CarType
    {
        Passenger = 0,
        Track = 1
    }
}
