﻿using System.Collections.Generic;

namespace BiencodeCarOwners.Models
{
    public class OwnerProfile
    {
        public Owner Owner { get; set; }
        public List<Car> Cars { get; set; }
    }
}
