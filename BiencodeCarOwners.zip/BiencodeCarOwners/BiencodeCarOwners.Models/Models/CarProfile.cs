﻿using System.Collections.Generic;

namespace BiencodeCarOwners.Models
{
    public class CarProfile
    {
        public Car Car { get; set; }
        public List<Owner> Owners { get; set; }
    }
}
